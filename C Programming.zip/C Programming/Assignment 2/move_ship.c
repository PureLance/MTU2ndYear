#include "asteroid.h"
//@Lance Hierco

struct ship_action move_ship(int field[][FIELD_WIDTH], void *ship_state) {
    static int current_row = FIELD_HEIGHT >> 1;
    int num_obstacles_in_current_row = 0;

    // Count the number of obstacles in the current and next row
    for (int i = 0; i < FIELD_WIDTH; i++) {
        if (field[current_row][i] == ASTEROID_VAL) {
            num_obstacles_in_current_row++;
        }
        if (field[current_row + MOVE_DOWN][i] == ASTEROID_VAL) {
            num_obstacles_in_current_row++;
        }
    }

    // Check if it is safe to move in the current direction
    int safe_to_move = 1;
    int next_row = current_row + MOVE_DOWN;
    for (int i = 0; i < FIELD_WIDTH; i++) {
        if (field[next_row][i] == ASTEROID_VAL) {
            safe_to_move = 0;
            break;
        }
    }

    // Check if it is safe to move down
    int safe_to_move_down = 1;
    int next_next_row = current_row + 2 * MOVE_DOWN;
    for (int i = 0; i < FIELD_WIDTH; i++) {
        if (field[next_next_row][i] == ASTEROID_VAL) {
            safe_to_move_down = 0;
            break;
        }
    }

    // Check if it is safe to move up
    int safe_to_move_up = 1;
    int prev_row = current_row + MOVE_UP;
    for (int i = 0; i < FIELD_WIDTH; i++) {
        if (field[prev_row][i] == ASTEROID_VAL) {
            safe_to_move_up = 0;
            break;
        }
    }

    // Check if there are obstacles in the row in front of the ship
    int obstacles_in_front = 0;
    for (int i = 0; i < FIELD_WIDTH; i++) {
        if (field[current_row][i] == ASTEROID_VAL) {
            obstacles_in_front = 1;
            break;
        }
    }

    // Decide which direction to move based on the number of obstacles in the current, next, and front rows
    int current_direction = MOVE_NO;
    if (num_obstacles_in_current_row == 0) {
        current_direction = MOVE_DOWN;
    } else if (obstacles_in_front == 0 && safe_to_move_down == 1) {
        current_direction = MOVE_DOWN;
    } else if (safe_to_move_up == 1) {
        current_direction = MOVE_UP;
    } else {
        current_direction = (current_direction == MOVE_UP) ? MOVE_DOWN : MOVE_UP;
    }

    // Update the ship's position based on the chosen direction
    if (current_direction == MOVE_DOWN && safe_to_move == 1) {
        current_row++;
    } else if (current_direction == MOVE_UP && safe_to_move_up == 1) {
        current_row--;
    }

    // Create and return a ship action struct
    struct ship_action action = { current_direction, &current_row };
    return action;
}
