#Assignment 1
#@Lance Hierco
#Q2
#Read in content
cardata <- read.table("D:/MTU/Yr2/Sem 2/Statistics&Probability/Assignment1/carsdataset.txt", header = TRUE)
attach(cardata)
cardata

str(cardata)

#Summary statistics for price
n<-length(Price) # sample size
xbar<-mean(Price) # sample mean
sigma<-9.6 # population standard deviation
std_error<-sigma/sqrt(n) # standard error

#Summary statistics for weight
n<-length(Weight) # sample size
xbar<-mean(Weight) # sample mean
sigma<-621.86 # population standard deviation
std_error<-sigma/sqrt(n) # standard error

#Based on information given to us by the two summary statistics, I believe using the measure of centrality mean, 
#and the measure of variability standard deviation would be appropriate for the values given to us




#Normality Check

#Histogram of Price
hist(Price, breaks=10, prob=TRUE, xlab="Price") 
curve(dnorm(x, mean=xbar, sd=sigma), col="darkblue", lwd=2, add=TRUE, yaxt="n")

#Histogram of Weight
hist(Weight, breaks=100, prob=TRUE, xlab="Weight") 
curve(dnorm(x, mean=xbar, sd=sigma), col="darkblue", lwd=2, add=TRUE, yaxt="n")

#Boxplot of Price
boxplot(carsdataset$Price, main = "Boxplot of Price",xlab = "Prices(in $1000)", col = "red", border = "blue", names = "Prices", horizontal = TRUE, at =1, add = FALSE)
#The boxplot for price shows that there are a few outliers on the right of the boxplot. So the data is right skewed.
#As it is right skewed I would use the median as my measure of centrality, as it is less effected by extreme values than the mean.
#For the measure of Variability I would go with the Interquartile Range. As the it is also less influenced by extreme values than the standard deviation.



#Boxplot of Weight
boxplot(carsdataset$Weight, main = "Boxplot of Weight",xlab = "Weight(in pounds)", col = "red", border = "blue", names = "Weights", horizontal = TRUE, at =1, add = FALSE)
#The boxplot shows one outlier on the left. The boxplot of weight is left skewed.
#For the measure of centrality I would go for the Median, as with the right skewed data, using the median is better than the mean as there is still an extreme value.
#For the measure of variability, I would go for the IQR as this is not as influenced by extreme data values.



#Q3

#Introductory Statement:
#The aim of this analysis is to check if there is a significant difference from two different factories

#null and alternative hypotheses
mu0 <- 3000

#Get sample of car weights
xbar<-mean(Weight) # sample mean
z<-(xbar-mu0)/std_error # z-statistic
z
#The z statistic is 0.98 

Pvalue<-2*pnorm(-abs(z)) # pnorm finds probability of being less than parameter
Pvalue

#Get histogram of the sample weight Normality check 1
hist(Weight, breaks=10, prob=TRUE, xlab="Sample weight") 
curve(dnorm(x, mean=xbar, sd=sigma), col="darkblue", lwd=2, add=TRUE, yaxt="n")

#Get qq line Normality check 2
# A Q-Q plot is a scatterplot created by plotting two sets of quantiles against one another. 
# If both sets of quantiles came from the same distribution, we should see 
# the points forming an approximate straight line. 
qqnorm(Weight,xlab="Sample weight",ylab="Occurances",main = "QQ Plot of Weight",col = "red")
qqline(Weight)

#Get weight from weight summary statistic

#Calculate test statistic

test_stat <- (xbar - 3000) / (sigma / sqrt(n))
p_value <- 2 * pt(-abs(test_stat), df = n-1)
test_stat
p_value
#The p_value is under 0.05, this means we reject h0 as it is not equal to 3000 pounds

#confidence interval - 95%
me<-qnorm(0.975)*std_error # First calculate the margin of error
me
xbar-me # Lower bound of interval
xbar+me # Upper bound of interval

#I am 95% confident that the confidence interval is in-between these 2 values

#Q4

#Summary statistics for Fuel tank
n<-length(Fuel.tank.capacity) # sample size
xbar<-mean(Fuel.tank.capacity) # sample mean
sigma<-3.2 # population standard deviation
std_error<-sigma/sqrt(n) # standard error


#A Assessing for normality using 2 graphs

#Histogram of fuel capacity
hist(Fuel.tank.capacity, breaks=10, prob=TRUE, col = "lightgreen", main = "Histogram of Fuel Tank", xlab="Fuel Capacity(Gallons)") 
curve(dnorm(x, mean=xbar, sd=sigma), col="darkblue", lwd=2, add=TRUE, yaxt="n")

#Normal probability plot of fuel capacity
qqnorm(Fuel.tank.capacity, xlab ="Sample of Fuel Tank", ylab = "Occurances",main = "QQPlot of Fuel Tank")
qqline(Fuel.tank.capacity)

#The normaility plot shows that the data points are linear


#Calculate t-value
t_value <- qt(0.95, df = n -1)

#Standard error of fuel tank mean

std_error <- sigma / sqrt(n)

#Calculating lower and upper bounds of CI
lower_bound <- xbar - t_value * std_error
upper_bound <- xbar + t_value * std_error

lower_bound
upper_bound
#The confidence interval is [16.07, 17.18]

#Hypothesis test

mu<- 15 # Mean value for the Null hypothesis
z<-(xbar-mu)/std_error # z-statistic
z

test_stat <- (xbar - mu) / std_error

P_value<- 1- pnorm(-abs(z)) # pnorm finds probability of being less than parameter
P_value

test_stat
P_value
#The test statistic is 4.89 which is much larger of 0.10, .and the P Value is less than 0.0001 which is much less than 0.05
#So we can reject the null hypothesis
#Using the sample data, I have a 90% CI for the true mean capacity being inbetween [16.26, 17.22] gallons
#In conclusion; based on this analysis I am 90% conifident that the mean fuel capacity greater or equal to 15 gallons.


#Q5


#Scatterplots
price <- (carsdataset$Price)
mpg <- (carsdataset$MPG.city)
hp <- (carsdataset$Horsepower)
rpm <- (carsdataset$RPM)

plot(price,mpg, main = "Price vs MPG",xlab = "Price",ylab = "MPG")
#These plot points create an almost straight line, therefore it has a linear relationship

plot(hp,rpm, main = "Horsepower vs RPM", xlab = "Horsepower", ylab ="RPM")
#These plot points are all scattered, showing that these have a weak or nonexistant relationship.








